﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace eblogram2._0spsmamezadetstvo
{
    /// <summary>
    /// Логика взаимодействия для server.xaml
    /// </summary>
    public partial class server : Window
    {
        private Socket Server;
        Socket socket;
        public List<Socket> clients = new List<Socket>();
        public server()
        {
            InitializeComponent();
            frame.Content = new Page1();

            IPEndPoint ipPoint = new IPEndPoint(IPAddress.Any, 8888);
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(ipPoint);
            socket.Listen(100);

            ListenToClients();
            
        }

        private void chat_Click(object sender, RoutedEventArgs e)
        {
            frame.Content = new Page1();
        }

        private void logs_Click(object sender, RoutedEventArgs e)
        {
            frame.Content = new Page2();
        }

        private async Task ListenToClients()
        {
            while (true)
            {
                var client = await socket.AcceptAsync();
                clients.Add(client);
                ReseiveMessage(client);


            }
        }

        private async Task ReseiveMessage(Socket client)
        {
            while (true)
            {
                byte[] bytes = new byte[1024];
                await client.ReceiveAsync(bytes, SocketFlags.None);

                string message = Encoding.UTF8.GetString(bytes);
                MassagesLbx.Items.Add(message);
                //MassagesLbx.Items.Add($"[Сообщение от {client.RemoteEndPoint}]:{message}");

                foreach (var item in clients)
                {
                    SendMessage(item, message);
                }
            }
        }

        private async Task SendMessage(Socket client, string message)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(message);
            await client.SendAsync(bytes, SocketFlags.None);
        }

        private void otprav_Click(object sender, RoutedEventArgs e)
        {
            if (txtq.Text == "/disconnect")
            {
                Server.Close();
                this.Close();
                MainWindow window = new MainWindow();
                window.Show();
            }
            else
            {
                
                SendMessageClient(txtq.Text);
                txtq.Text = "";
            }
        }


        private async Task SendMessageClient(string message)
        {
            
            byte[] bytes = Encoding.UTF8.GetBytes(message);

            await Server.SendAsync(bytes, SocketFlags.None);
        }
    }
}
