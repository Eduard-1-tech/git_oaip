﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace eblogram2._0spsmamezadetstvo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string Login;

        public string IPi;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void new_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text == "" || ip.Text == "")
            {
                error_box.Text = "Не все поля заполнены";
            }
            else
            {
                server server = new server();
                server.Show();
                this.Close();
            }
        }



        private void login_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            error_box.Text = "";
        }

        private void ip_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            error_box.Text = "";
        }

        private void connect_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text == "" || ip.Text == "")
            {
                error_box.Text = "Не все поля заполнены";
            }
            else
            {
                Login= login.Text;
                IPi= ip.Text;
                MessageBox.Show(IPi);
                //blb yf [eq
                client client= new client();
                //DialogResult = true;
                client.Show();
                Close();
            }
        }

        
    }
}
