﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace eblogram2._0spsmamezadetstvo
{
    
    ///dsnv ncvdjkv fvj huhu huhuds sduhfu sfhv sdfhdjksfhj sdhfj jdhfk hfweoe c j dvi
    /// <summary>
    /// Логика взаимодействия для client.xaml
    /// </summary>
    public partial class client : Window
    {
        private Socket server;
        public string ipip;
        public client()
        {
            InitializeComponent();
            MainWindow window= new MainWindow();
            string ipip = window.IPi;
            MessageBox.Show(window.IPi);
            MessageBox.Show(ipip);
            
            server = new Socket (AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
            server.ConnectAsync("127.0.0.1", 8888);
            ResieveMessage();
        }

        private async Task ResieveMessage()
        {
            while (true)
            {
                byte[] bytes = new byte[1024];
                await server.ReceiveAsync(bytes,SocketFlags.None);
                string message = Encoding.UTF8.GetString(bytes);

                MessageLbx.Items.Add(message);
            }
        }

        private async Task SendMessage(string message)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(message);
            await server.SendAsync(bytes, SocketFlags.None);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (txtq.Text == "/disconnect")
            {
                server.Close();
                this.Close();
                MainWindow window = new MainWindow();
                window.Show();
            }
            else
            {
                SendMessage(txtq.Text);
                txtq.Text = "";
            }
        }

        private void vihod_Click(object sender, RoutedEventArgs e)
        {
            server.Close();
            this.Close();
            MainWindow window= new MainWindow();
            window.Show();
        }

        private void otprav_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                otprav.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
        }

        private void txtq_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtq.Text != "") 
            {
                if (e.Key == Key.Enter)
                {
                    otprav.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
            }
        }
    }
}
