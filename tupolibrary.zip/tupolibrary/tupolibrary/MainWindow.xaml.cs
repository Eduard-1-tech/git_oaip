﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary1;

namespace tupolibrary
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void age_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            Person person = new Person
            {

                Name = name.Text,
                Age = int.Parse(age.Text),
                Gender = gender.Text
            };

            Class1.Serialize(person);
            name.Text = "";
            age.Text = "";
            gender.Text = "";

        }

        private void show_Click(object sender, RoutedEventArgs e)
        {
            string filePath = "C:\\Users\\Эдуард\\Desktop\\Person2.json";
            var person = Class1.Deserialize<Person>(filePath);
            
            name1.Text = person.Name;
            age1.Text = person.Age.ToString();
            gender1.Text = person.Gender.ToString();
            
            
        }
    }
}
