﻿using System.Text.Json;
using Newtonsoft.Json;

namespace ClassLibrary1
{
    public class Class1
    {
        public static T Deserialize<T>(string filePath)
        {
            //string filePath = "C:\\Users\\Эдуард\\Desktop\\Person2.json";
            string json = File.ReadAllText(filePath);
            T humans = JsonConvert.DeserializeObject<T>(json);
            return humans;
        }

        public static void Serialize<T>(T obj)
        {
            string filePath = "C:\\Users\\Эдуард\\Desktop\\Person2.json";
            String json = JsonConvert.SerializeObject(obj);
            File.WriteAllText("C:\\Users\\Эдуард\\Desktop\\Person2.json", json);
        }
    }
}