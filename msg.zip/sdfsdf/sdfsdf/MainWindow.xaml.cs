﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace sdfsdf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string IP;
        public string Login;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void create_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text == "" )
            {
                error_box.Text = "Не все поля заполнены";
            }
            else
            {
                IP = ip.Text;

                //DialogResult = true;
                Login = login.Text;
                admin admin = new admin(Login);
                admin.Show();
                this.Hide();

                
            }
        }

        private void in_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text == "" || ip.Text == "")
            {
                error_box.Text = "Не все поля заполнены";
            }
            else
            {

                
                IP = ip.Text;
                Login = login.Text;
                if (IP == "127.0.0.1")
                {
                    //admin admin = new admin(Login);
                    chat chat = new chat(IP,Login);
                    chat.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("что-то пошло не так(");
                }
                
            }
        }

        private void login_TextChanged(object sender, TextChangedEventArgs e)
        {
            error_box.Text = "";
        }

        private void ip_TextChanged(object sender, TextChangedEventArgs e)
        {
            error_box.Text = "";
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {   
        }
    }
}
