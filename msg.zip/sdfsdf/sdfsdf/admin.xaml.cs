﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace sdfsdf
{
    /// <summary>
    /// Логика взаимодействия для admin.xaml
    /// </summary>
    public partial class admin : Window
    {
        private Socket socket;
        private List<Socket> clients = new List<Socket>();
        public string Login;
        public admin(string login)
        {
            InitializeComponent();
            Login = login;
            IPEndPoint ipPoint = new IPEndPoint(IPAddress.Any, 8888);
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(ipPoint);
            socket.Listen(100);

            ListenToClients();
        }
        
        private async Task ListenToClients()
        {
            while (true)
            {
                var client = await socket.AcceptAsync();
                clients.Add(client);

                ReseiveMessage(client);


            }
        }

        
        private async Task ReseiveMessage(Socket client)
        {
            while (true)
            {
                byte[] bytes = new byte[1024];
                await client.ReceiveAsync(bytes, SocketFlags.None);

                string message = Encoding.UTF8.GetString(bytes);

                string[] parts = message.Split(new[] { ':' }, 2);
                string username = parts.Length > 0 ? parts[0] : "[unknown]";
                MessageBox.Show(parts[0]);
                MessageBox.Show(parts[1]);
                msglbx.Items.Add($"{username}:{(parts.Length > 1 ? parts[1] : "")}");

                //msglbx.Items.Add(message);
                //msglbx.Items.Add($"[Сообщение от {client.RemoteEndPoint}]:{message}");

                foreach (var item in clients)
                {
                    SendMessage(item, message);
                }
            }
        }

        private async Task SendMessage(Socket client, string message)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(message);
            await client.SendAsync(bytes, SocketFlags.None);
        }

        private async Task SendMessageToAll(string message)
        {
            foreach (var item in clients)
            {
                await SendMessage(item, $"[{DateTime.Now}[Админ]]: {message}");
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void otprav_Click(object sender, RoutedEventArgs e)
        {
            if (txt.Text != "") { 
            string message = txt.Text;
            txt.Text = ""; // Очищаем поле ввода сообщения
            msglbx.Items.Add($"[Вы]: {message}");
            SendMessageToAll(message);
            }
        }

        private void close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            MainWindow window = new MainWindow();
            window.Visibility= Visibility.Collapsed;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = false;
            MainWindow window = new MainWindow();
            window.Show();
        }

        private void txt_KeyUp(object sender, KeyEventArgs e)
        {
            if (txt.Text != "")
            {
                if (e.Key == Key.Enter)
                {
                    otprav.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
            }
        }
    }
}
