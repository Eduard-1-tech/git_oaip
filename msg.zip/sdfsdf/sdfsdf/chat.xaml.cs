﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace sdfsdf
{
    /// <summary>
    /// Логика взаимодействия для chat.xaml
    /// </summary>
    public partial class chat : Window
    {
        private Socket server;
        private string Login;
        public chat(string IP,string login)
        {
            InitializeComponent();
            this.Login = login;
            
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            server.ConnectAsync(IP, 8888);
            ResieveMessage();
        }

        private async Task ResieveMessage()
        {
            while (true)
            {
                byte[] bytes = new byte[1024];
                await server.ReceiveAsync(bytes, SocketFlags.None);
                string message = Encoding.UTF8.GetString(bytes);

                msglbx.Items.Add(message);
            }
        }

        private async Task SendMessage(string message)
        {
            byte[] bytes = Encoding.UTF8.GetBytes($"[{DateTime.Now}[{Login}]]: {message}");
            await server.SendAsync(bytes, SocketFlags.None);
        }

        private void vihod_Click(object sender, RoutedEventArgs e)
        {
            server.Close();
            this.Close();
            MainWindow window = new MainWindow();
            window.Show();
        }

        private void otprav_Click(object sender, RoutedEventArgs e)
        {
            if (msg.Text == "/disconnect")
            {
                server.Close();
                this.Close();
                MainWindow window = new MainWindow();
                window.Show();
            }
            else
            {
                SendMessage(msg.Text);
                msg.Text = "";
            }
        }

        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void msg_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void msg_KeyUp(object sender, KeyEventArgs e)
        {
            if (msg.Text != "")
            {
                if (e.Key == Key.Enter)
                {
                    otprav.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                }
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = false;
            MainWindow window= new MainWindow();
            window.Show();
            
        }
    }
}
